## Trocmedoc

An application to make drug bartering

## Build status

[![Build Status](https://travis-ci.org/Andriantomanga/trocmedoc.svg?branch=master)](https://travis-ci.org/Andriantomanga/trocmedoc)

